import urllib3
from bs4 import BeautifulSoup as soup


def lambda_handler(event, context):
    # TODO implement
    # http_method = event.get('httpMethod')
    # query_string = event.get('queryStringParameters')
    # headers = event.get('headers')
    url = event.get('url')
    # url = "https://www.google.com/search?q=python+programming"
    http = urllib3.PoolManager()
    r = http.request('GET', url)
    body = r.data

    page_soup = soup(r.data, "html.parser")
    meta_description = page_soup.find('meta', attrs={'name': 'description'})
    meta_title = page_soup.find('title')

    return {
        'statusCode': r.status,
        'metaDescription': meta_description.get('content'),
        'title': meta_title.string,
    }
